# alpeso-test
alpeso-test

## How-to use

Simple run ```./keycloack.sh test test1``` where test = keycloak user id and test1 = keycloak client secret.
