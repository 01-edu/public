#!/usr/bin/env bash

cp -r struct new-struct && cd new-struct/ && rm -r 5/ && mkdir -p 0_to_3 6_to_9 && mv 0/ 1/ 2/ 3/ 0_to_3 && mv 6/ 7/ 8/ 9/ 6_to_9/
tree
