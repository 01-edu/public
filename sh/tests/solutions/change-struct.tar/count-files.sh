#!/usr/bin/env bash

find . -type d,f | wc -l
