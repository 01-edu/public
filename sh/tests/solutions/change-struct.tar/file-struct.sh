#!/usr/bin/env bash

mkdir struct && cd struct/ && mkdir -p 0 1 2 3 4 5 6 7 8 9 A && ls -1
